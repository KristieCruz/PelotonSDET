//Imports are listed in full to show what's being used
//could just import javax.swing.* and java.awt.* etc..
import java.awt.EventQueue;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.AlphaComposite;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.ImageObserver;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.* ;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

import net.beadsproject.beads.core.*;
import net.beadsproject.beads.events.*;
import net.beadsproject.beads.ugens.*;
import net.beadsproject.beads.data.*;

import java.io.File;

import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Hashtable;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.Toolkit;
import javax.swing.UIManager.*;

import java.awt.Toolkit;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.plaf.ComboBoxUI;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.ToolTipManager;

// layout imports
import net.miginfocom.layout.AC;
import net.miginfocom.layout.CC;
import net.miginfocom.layout.LC;
import net.miginfocom.swing.MigLayout;

import java.awt.Toolkit;

// javacv imports 
import static com.googlecode.javacv.cpp.opencv_core.*;
import com.googlecode.javacv.cpp.opencv_core;
import static com.googlecode.javacv.cpp.opencv_imgproc.*;
import static com.googlecode.javacv.cpp.opencv_highgui.*;

import com.googlecode.javacv.*;
import com.googlecode.javacv.CanvasFrame;
import com.googlecode.javacv.FrameGrabber;
import com.googlecode.javacv.OpenCVFrameGrabber;
import static com.googlecode.javacv.cpp.opencv_core.cvFlip;
import com.googlecode.javacv.cpp.opencv_core.IplImage;

import com.googlecode.javacpp.Loader;
import static com.googlecode.javacpp.Loader.*;

import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.*;

// look and feel
import javax.swing.plaf.synth.*;

public class Weather extends JFrame {

	// set to detect red color
	static int hueLowerR = -5; // 160;
	static int hueUpperR = 5; // 180;

	// initial settings
	private int height = 480;
    private int width = 320;
	private boolean s = true; // true when small screen
	static boolean o = false; // false when object detection turned off
	static boolean m = true; // Sound mute

	private JComboBox locationsList;

	JLabel day;
	JLabel high;
	JLabel low;
	JLabel text;

	static JLabel timersecLabel;

	final JLabel iconLabel1 = new JLabel();

	JLabel panel;
	BufferedImage icon;

	// images used for buttons
	static BufferedImage objImage;
	static BufferedImage muteImage;
	static BufferedImage sizeImage;

	static BufferedImage launchImage;

	static int small;
	static int big;
	static int font;

	static int tSec;
	static int tMin;
	static int tHour;
	static String ts;
	static String tm;
	static String tm1;
	static String ts1;

	// buttons for turning on and off object detection & resizing the screen
	static JButton objButton;
	static JButton muteButton;
	static JButton sizeButton;

	static JButton startRunning;
	static BufferedImage runningImage;
	static JButton refresh;
	static BufferedImage refreshImage;
	static Timer timer;
	static boolean timerBool;

    // used for getting the correct jslider value
	static int val;
	public static int yay; 
	int i;

	// array of weather icons
	public BufferedImage[] bImg;
	
	// slider values
    static final int FPS_MIN = 0;
    static final int FPS_MAX = 4;
    static final int FPS_INIT = 4; 

    static JSlider slider2;

	Clip clip;
	
	WeatherAPI weather;

	static JFrame frame = new JFrame("WeatherRun");

	String[] locations = { "London", "Miami", "Los Angeles", "Oxford", "Tokyo" };
	String[] locationCodes = {"44418", "2450022", "2442047", "31278", "1118370"};

	// values used in iterating through the forecast/conditions arraylists
	static String j;
	static int k;

    public Weather() { // --------------------------------------------------------constructor---------------------------------------------------------------------------------------

    	// set the look and feel 
        try {
            SynthLookAndFeel laf = new SynthLookAndFeel();
            laf.load(Weather.class.getResourceAsStream("demo.xml"), Weather.class); 
            UIManager.setLookAndFeel(laf);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        initUI();
    } // -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 private void initUI() {

/*** LOAD ICONS ***/
final BufferedImage[] bImg = new BufferedImage[47]; 
                try {
						for(i=0; i<47; i++)
                   		 bImg[i] = ImageIO.read(new File("icons/" + i + ".png"));
                } catch (IOException exp) {
                    exp.printStackTrace();
		}

/*** SOUNDS ***/
final AudioContext ac = new AudioContext(); 


/*** SETUP ***/
	setTitle("Weather");
	this.weather = new WeatherAPI("44418"); // London is the default city
       setSize(width, height);
       setLocationRelativeTo(null); // center the frame
       setAlwaysOnTop(true); // set frame always on top
       setDefaultCloseOperation(EXIT_ON_CLOSE);

/*** BACKGROUND ***/
	final JLabel panel = new JLabel(new ImageIcon("images/2.jpg"));
	add(panel);
	panel.setLayout(new MigLayout(new LC().fill(), new AC().grow(), new AC().grow()));

/*** BACKGROUND LAUNCH***/
	final JLabel launchlop = new JLabel(new ImageIcon("images/launch.jpg"));
	add(panel);
	
small = 25;
big = 50;

/*** OBJECT BUTTON (EYE) ***/ 
objImage = null;

try {
 objImage = ImageIO.read(new File("images/eye.png"));
 objImage = resize(objImage, small, small);
} catch (IOException e) {
            e.printStackTrace();
 }

objButton = new JButton(new ImageIcon(objImage));
objButton.setBorder(BorderFactory.createEmptyBorder());
objButton.setToolTipText("<html>Object Recognition button for turning on and off <br>" + 
								"object recognition feature. <br></html>");
objButton.setContentAreaFilled(false);	
Dimension d = getPreferredSize();
d.setSize(small, small);
objButton.setPreferredSize(d);
       
       objButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent event) {
				if(m==true){
					try{
					    Sample selectedSample = SampleManager.sample("sounds/boop.wav");
					    // create a sample player
					    SamplePlayer samplePlayer = new SamplePlayer(ac,selectedSample);						
					   				
					    // set to kill on end, so when the sample finished
					    // the sample player is removed from the audio context (to free up CPU resources)
					    samplePlayer.setKillOnEnd(true);  
					    // IMPORTANT
					    // add the sample player to the audio context's output
					    ac.out.addInput(samplePlayer);   
						ac.start();       
 					} catch (Exception expe) {
                    expe.printStackTrace();
					}
				}

             	if(o==false){ 
					o=true;
			} else if(o==true) {
					o=false;
			}			
          }
       });

/*** Mute BUTTON ***/ 
muteImage = null;

try {
	 muteImage = ImageIO.read(new File("images/mute1.png"));
	 muteImage = resize(muteImage, small, small);
} catch (IOException e) {
     e.printStackTrace();
}

muteButton = new JButton(new ImageIcon(muteImage));
muteButton.setBorder(BorderFactory.createEmptyBorder());
muteButton.setContentAreaFilled(false);	
muteButton.setToolTipText("Turn sound on/off.");
Dimension dl = getPreferredSize();
dl.setSize(small, small);
muteButton.setPreferredSize(dl);
       
       muteButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent event) {
				if(m==false){
					try{
					    Sample selectedSample = SampleManager.sample("sounds/boop.wav");
					    // create a sample player
					    SamplePlayer samplePlayer = new SamplePlayer(ac,selectedSample);						
					   				
					    // set to kill on end, so when the sample finished
					    // the sample player is removed from the audio context (to free up CPU resources)
					    samplePlayer.setKillOnEnd(true);  
					    // IMPORTANT
					    // add the sample player to the audio context's output
					    ac.out.addInput(samplePlayer);   
						ac.start();       
 					} catch (Exception expe) {
                   		expe.printStackTrace();
					}
				}

             if(m==false){ 
				m=true;
			} else if(m==true) {
				m=false;
			}			
          }
       });



/*** Start Running Running Timer ***/


/*** START RUNNING ***/
startRunning = new JButton("Start Running");
runningImage = null;
timerBool = false;

try {
 runningImage = ImageIO.read(new File("images/start.png"));
 runningImage = resize(runningImage, small, small);
} catch (IOException e) {
            e.printStackTrace();
 }

startRunning = new JButton(new ImageIcon(runningImage));
startRunning.setBorder(BorderFactory.createEmptyBorder());
startRunning.setToolTipText("Start Running!");
startRunning.setContentAreaFilled(false);	
Dimension d3 = getPreferredSize();
d3.setSize(small, small);
startRunning.setPreferredSize(d3);  

       startRunning.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent event) {
           	if(timerBool==false){
           		timerBool = true;
           		timer.start();           		
           	} else if(timerBool==true){
           		timerBool = false;
           		timer.stop();
           	}			
          }
       }); 

/*** REFRESH TIMER ***/
refresh = new JButton("Refresh Timer");
refreshImage = null;

try {
 refreshImage = ImageIO.read(new File("images/refresh.png"));
 refreshImage = resize(refreshImage, small, small);
} catch (IOException e) {
            e.printStackTrace();
 }

refresh = new JButton(new ImageIcon(refreshImage));
refresh.setBorder(BorderFactory.createEmptyBorder());
refresh.setToolTipText("Refresh Timer!");
refresh.setContentAreaFilled(false);	
Dimension d4 = getPreferredSize();
d4.setSize(small, small);
refresh.setPreferredSize(d4);  

       refresh.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent event) {
				tSec = 0;
				tMin = 0;
				timersecLabel.setText("00:00");			
          }
       }); 


/*** RESIZE BUTTON ***/ 
sizeImage = null;

try {
	 sizeImage = ImageIO.read(new File("images/resizeFlat.png"));
	 sizeImage = resize(sizeImage, small, small);
} catch (IOException e) {
     e.printStackTrace();
}

sizeButton = new JButton(new ImageIcon(sizeImage));
sizeButton.setBorder(BorderFactory.createEmptyBorder());
sizeButton.setContentAreaFilled(false);
sizeButton.setToolTipText("Resize screen.");
Dimension d1 = getPreferredSize();
d1.setSize(small, small);
sizeButton.setPreferredSize(d1);
       
       // when clicked, change screen size
       sizeButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent event) {
				if(m==true){
					try{
					    Sample selectedSample = SampleManager.sample("sounds/boop.wav");
					    // create a sample player
					    SamplePlayer samplePlayer = new SamplePlayer(ac,selectedSample);						
					   				
					    // set to kill on end, so when the sample finished
					    // the sample player is removed from the audio context (to free up CPU resources)
					    samplePlayer.setKillOnEnd(true);  
					    // IMPORTANT
					    // add the sample player to the audio context's output
					    ac.out.addInput(samplePlayer);   
						ac.start();       
 					} catch (Exception expe) {
                   		expe.printStackTrace();
					}
				}

               if(s==true){
					s = false; // make screen bigger
					setSize(480, 640);
					font = 20;
					day.setFont(new Font("SansSerif", Font.PLAIN, font));
					high.setFont(new Font("SansSerif", Font.PLAIN, font));
					low.setFont(new Font("SansSerif", Font.PLAIN, font));
					text.setFont(new Font("SansSerif", Font.PLAIN, font));
					
					locationsList.setFont(new Font("SansSerif", Font.BOLD, 24));
					slider2.setPreferredSize(new Dimension(50, 580));

					// resize all icons 

					try {
 						sizeImage = ImageIO.read(new File("images/resizeFlat.png"));
 						sizeImage = resize(sizeImage, big, big);
			          	Dimension d1 = getPreferredSize();
			            d1.setSize(big, big);
						sizeButton.setPreferredSize(d1);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						sizeButton.setIcon(new ImageIcon(sizeImage));

					try {
 						muteImage = ImageIO.read(new File("images/mute1.png"));
 						muteImage = resize(muteImage, big, big);
			          	Dimension d1 = getPreferredSize();
			            d1.setSize(big, big);
						sizeButton.setPreferredSize(d1);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						muteButton.setIcon(new ImageIcon(muteImage));

					try {
 						runningImage = ImageIO.read(new File("images/start.png"));
 						runningImage = resize(runningImage, big, big);
			          	Dimension d3 = getPreferredSize();
			            d3.setSize(big, big);
						startRunning.setPreferredSize(d3);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						startRunning.setIcon(new ImageIcon(runningImage));		

					try {
 						refreshImage = ImageIO.read(new File("images/refresh.png"));
 						refreshImage = resize(refreshImage, big, big);
			          	Dimension d4 = getPreferredSize();
			            d4.setSize(big, big);
						refresh.setPreferredSize(d4);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						refresh.setIcon(new ImageIcon(refreshImage));											


					try {
 						objImage = ImageIO.read(new File("images/eye.png"));
 						objImage = resize(objImage, big, big);
			          	Dimension d = getPreferredSize();
			            d.setSize(big, big);
						objButton.setPreferredSize(d);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}

						objButton.setIcon(new ImageIcon(objImage));	
						j = weather.weatherForecastList.get(yay).codeForecast;
						k = Integer.parseInt(j);
						BufferedImage resizedImage=resize(bImg[k],300,300);
						ImageIcon op = new ImageIcon(resizedImage);
						iconLabel1.setIcon(op);
						
			} else { 
					s = true; // make screen smaller
					setSize(320, 480);
					font = 14;

					day.setFont(new Font("SansSerif", Font.PLAIN, font));
					high.setFont(new Font("SansSerif", Font.PLAIN, font));
					low.setFont(new Font("SansSerif", Font.PLAIN, font));
					text.setFont(new Font("SansSerif", Font.PLAIN, font));
					
					locationsList.setFont(new Font("SansSerif", Font.BOLD, 18));

					slider2.setPreferredSize(new Dimension(50, 450));

					// resize all icons
					try {
 						sizeImage = ImageIO.read(new File("images/resizeFlat.png"));
 						sizeImage = resize(sizeImage, small, small);
			          	Dimension d1 = getPreferredSize();
			            d1.setSize(small, small);
						sizeButton.setPreferredSize(d1);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}				
 						sizeButton.setIcon(new ImageIcon(sizeImage)); 

					try {
 						muteImage = ImageIO.read(new File("images/mute1.png"));
 						muteImage = resize(muteImage, small, small);
			          	Dimension dl = getPreferredSize();
			            dl.setSize(small, small);
						muteButton.setPreferredSize(dl);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}				
 					muteButton.setIcon(new ImageIcon(muteImage)); 

					try {
 						runningImage = ImageIO.read(new File("images/start.png"));
 						runningImage = resize(runningImage, small, small);
			          	Dimension d3 = getPreferredSize();
			            d3.setSize(big, big);
						startRunning.setPreferredSize(d3);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						startRunning.setIcon(new ImageIcon(runningImage));	 

					try {
 						refreshImage = ImageIO.read(new File("images/refresh.png"));
 						refreshImage = resize(refreshImage, small, small);
			          	Dimension d4 = getPreferredSize();
			            d4.setSize(big, big);
						refresh.setPreferredSize(d4);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						refresh.setIcon(new ImageIcon(refreshImage));											

					try {
 						objImage = ImageIO.read(new File("images/eye.png"));
 						objImage = resize(objImage, small, small);
			          	Dimension d = getPreferredSize();
			            d.setSize(small, small);
						objButton.setPreferredSize(d);

					} catch (IOException e) {
           				 e.printStackTrace();
 					}
						objButton.setIcon(new ImageIcon(objImage));	

						j = weather.weatherForecastList.get(yay).codeForecast;
						k = Integer.parseInt(j);
						BufferedImage resizedImage=resize(bImg[k],200,200);
						ImageIcon op = new ImageIcon(resizedImage);
						iconLabel1.setIcon(op);											 												
			}	
          }
      	}				
      );


/*** INITIAL LABEL ***/
	day = new JLabel();
	high = new JLabel();
	low = new JLabel();
	text = new JLabel();

	day.setFont(new Font("SansSerif", Font.PLAIN, 14));
	high.setFont(new Font("SansSerif", Font.PLAIN, 14));
	low.setFont(new Font("SansSerif", Font.PLAIN, 14));
	text.setFont(new Font("SansSerif", Font.PLAIN, 14));

	day.setText("Day: " + weather.weatherForecastList.get(yay).day);
	high.setText("High: " + weather.weatherForecastList.get(yay).highTemp + "\u00b0C");
	low.setText("Low: " + weather.weatherForecastList.get(yay).lowTemp + "\u00b0C");
	text.setText("Forecast: " + weather.weatherForecastList.get(yay).textForecast);
	
/*** INITAL ICONS ***/
	j = weather.weatherForecastList.get(yay).codeForecast;
	k = Integer.parseInt(j);
	BufferedImage resizedImage=resize(bImg[k],200,200);
	ImageIcon op = new ImageIcon(resizedImage);
	iconLabel1.setIcon(op);

/*** LOCATION BOX ***/ 
    locationsList = new JComboBox(locations);
	locationsList.setSelectedIndex(0);
	locationsList.setPreferredSize(new Dimension(2*width/5, height/20));
	locationsList.setFont(new Font("SansSerif", Font.BOLD, 18));
	locationsList.setUI((ComboBoxUI) MyComboBoxUI.createUI(locationsList));
	locationsList.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent event) {
				if(m==true){
					try{
					    Sample selectedSample = SampleManager.sample("sounds/boop.wav");
					    // create a sample player
					    SamplePlayer samplePlayer = new SamplePlayer(ac,selectedSample);						
					   				
					    // set to kill on end, so when the sample finished
					    // the sample player is removed from the audio context (to free up CPU resources)
					    samplePlayer.setKillOnEnd(true);  
					    // IMPORTANT
					    // add the sample player to the audio context's output
					    ac.out.addInput(samplePlayer);   
						ac.start();       
 					} catch (Exception expe) {
                    	expe.printStackTrace();
					}
				}
						weather = new WeatherAPI(locationCodes[locationsList.getSelectedIndex()]);
						day.setText("Day: " + weather.weatherForecastList.get(yay).day);
						high.setText("High: " + weather.weatherForecastList.get(yay).highTemp + "\u00b0C");
						low.setText("Low: " + weather.weatherForecastList.get(yay).lowTemp + "\u00b0C");
						text.setText("Forecast: " + weather.weatherForecastList.get(yay).textForecast);


				if (s==false){

						j = weather.weatherForecastList.get(yay).codeForecast;
						k = Integer.parseInt(j);
						BufferedImage resizedImage=resize(bImg[k],300,300);
						ImageIcon op = new ImageIcon(resizedImage);
						iconLabel1.setIcon(op);

				} else if (s==true){

						j = weather.weatherForecastList.get(yay).codeForecast;
						k = Integer.parseInt(j);
						BufferedImage resizedImage=resize(bImg[k],200,200);
						ImageIcon op = new ImageIcon(resizedImage);
						iconLabel1.setIcon(op);
				}

	}
});

	

/*** SLIDER ***/

	slider2 = new JSlider(JSlider.VERTICAL, FPS_MIN, FPS_MAX, FPS_INIT);
 	slider2.setPaintTicks(true);
	slider2.setPaintLabels(true);
	slider2.setOpaque(false);
	slider2.setPreferredSize(new Dimension(30, 450));

	Font font = new Font("Serif", Font.ITALIC, 0); // couldn't get rid of the value on top, so i made it 0 size
	slider2.setFont(font);

	Hashtable labelTable = new Hashtable();
	labelTable.put( new Integer( 0 ), new JLabel(weather.weatherForecastList.get(4).day) );
	labelTable.put( new Integer( FPS_MAX/4 ), new JLabel(weather.weatherForecastList.get(3).day) );
	labelTable.put( new Integer( 2*FPS_MAX/4 ), new JLabel(weather.weatherForecastList.get(2).day) );
	labelTable.put( new Integer( 3*FPS_MAX/4 ), new JLabel(weather.weatherForecastList.get(1).day) );
	labelTable.put( new Integer( FPS_MAX ), new JLabel(weather.weatherForecastList.get(0).day) );

	slider2.setLabelTable( labelTable );
 
	slider2.addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
	val = slider2.getValue();

// done faster than absolute subtracting 
	yay = 0;

	if(val == 4)
		yay = 0;
	if(val == 3)
		yay = 1;
	if(val == 2)
		yay = 2;
	if(val == 1)
		yay = 3;
	if(val == 0)
		yay = 4;

	day.setText("Day: " + weather.weatherForecastList.get(yay).day);
	high.setText("High: " + weather.weatherForecastList.get(yay).highTemp + "\u00b0C");
	low.setText("Low: " + weather.weatherForecastList.get(yay).lowTemp + "\u00b0C");
	text.setText("Forecast: " + weather.weatherForecastList.get(yay).textForecast);
	
		if (s==false){

			j = weather.weatherForecastList.get(yay).codeForecast;
			k = Integer.parseInt(j);
			BufferedImage resizedImage=resize(bImg[k],300,300);
			ImageIcon op = new ImageIcon(resizedImage);
			iconLabel1.setIcon(op);

		} else if (s==true){

			j = weather.weatherForecastList.get(yay).codeForecast;
			k = Integer.parseInt(j);
			BufferedImage resizedImage=resize(bImg[k],200,200);
			ImageIcon op = new ImageIcon(resizedImage);
			iconLabel1.setIcon(op);
		}


		if(m==true){
			try{
			    Sample selectedSample = SampleManager.sample("sounds/bell.wav");
			    // create a sample player
			    SamplePlayer samplePlayer = new SamplePlayer(ac,selectedSample);						
			   				
			    // set to kill on end, so when the sample finished
			    // the sample player is removed from the audio context (to free up CPU resources)
			    samplePlayer.setKillOnEnd(true);  
			    // IMPORTANT
			    // add the sample player to the audio context's output
			    ac.out.addInput(samplePlayer);   
				ac.start();       
 			} catch (Exception expe) {
                    expe.printStackTrace();
			}
		}
      }
    });

	slider2.setVisible(true);

/*** TIMER  ***/

timersecLabel = new JLabel();
timersecLabel.setOpaque(true);
timersecLabel.setBackground(Color.white);
timersecLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
timersecLabel.setText("00:00");	

// add all the components
	
	panel.add(launchlop);

	panel.add(sizeButton);
	panel.add(muteButton);
	panel.add(objButton); 
	panel.add(slider2, "span 1 3, wrap"); 
	panel.add(iconLabel1, "span 3 1, wrap");
	panel.add(locationsList, "span 3 1, wrap"); 


	panel.add(day, "wrap, gaptop 10, span 3 1");
	panel.add(high, "gaptop 5, span 2 1");
	panel.add(timersecLabel, "align right, span 2 1, gaptop 5, wrap");
	panel.add(low, "wrap, gaptop 5, span 3 1");
	panel.add(text, "gaptop 5, span 3 1");

	panel.add(startRunning);
	panel.add(refresh);


try{
 ActionListener taskPerformer1 = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                //...Perform a task...
	tHour++;
		if(tHour > 8){
	panel.remove(launchlop);
}
            }
            };
        Timer timer1 = new Timer( 1000 , taskPerformer1);
        timer1.setRepeats(true);
        timer1.start();

        Thread.sleep(5000);
} catch (Exception expec) {
                    expec.printStackTrace();
			}

}

 public static void main(String[] args) throws Exception {
        
        
                Weather ex = new Weather();
                ex.setVisible(true);

/*** TIMER ***/
    ActionListener taskPerformer = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                //...Perform a task...
if(tSec<59){    
		tSec++;
		tm = Integer.toString(tMin);
		ts = Integer.toString(tSec);
		String tm1 = String.format("%02d", tMin);
		String ts1 = String.format("%02d", tSec);
                timersecLabel.setText(tm1 + ":" + ts1);
}
else{ 
		tSec=0;
		tMin++;
		ts = Integer.toString(tSec);
           
		tm = Integer.toString(tMin);
		String tm1 = String.format("%02d", tMin);
		String ts1 = String.format("%02d", tSec);
               
		timersecLabel.setText(tm1 + ":" + ts1);

}



            }
            };

        timer = new Timer( 1000 , taskPerformer);
        timer.setRepeats(true);
        //timer.start();

        Thread.sleep(5000);


/***CAM***/
OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0);
                                                grabber.start();
		//Create canvas frame for displaying webcam.
		CanvasFrame canvasW = new CanvasFrame("Webcam");
                                                CanvasFrame canvasT = new CanvasFrame("Thresholded");

		//Set Canvas frame to close on exit
                                                //canvasW.setDefaultCloseOperation(CanvasFrame.EXIT_ON_CLOSE);   

		IplImage orgImg = grabber.grab();
		  //Set canvas size as per dimentions of video frame.
		 canvasW.setCanvasSize(grabber.getImageWidth(), grabber.getImageHeight());
		 canvasT.setCanvasSize(grabber.getImageWidth(), grabber.getImageHeight());
		  		        
                                            while (canvasW.isVisible() && (orgImg = grabber.grab()) != null) {

		  // threshold the captured image using the lower and upper thresholds
		  // defined above
		  IplImage thresholdImage = hsvThreshold(orgImg);
		  CvMemStorage mem = CvMemStorage.create();
		  CvSeq contours = new CvSeq(orgImg);

	                           contours = cvCreateSeq(0, sizeof(CvContour.class),
					sizeof(CvSeq.class), mem);

		   cvFindContours(thresholdImage.clone(), mem, contours,
					Loader.sizeof(CvContour.class), CV_RETR_CCOMP,
					CV_CHAIN_APPROX_SIMPLE, cvPoint(0, 0));
                                                    //  see end of the code for explanation on contours                        
                                                    while (contours != null && !contours.isNull()) {
                                                                                                // define a 2D rectangle structure that will be the bounding box of the contour of the object
				CvRect br = cvBoundingRect(contours, 1);
				// draw a GREEN rectangle around the contour (of the object detected)
				cvRectangle(orgImg, cvPoint(br.x(), br.y()),
						cvPoint(br.x() + br.width(), br.y() + br.height()),
						CvScalar.GREEN, 3, CV_AA, 0);
						int y = br.y();
						y = 5*y/480;
						y = -y+4;
						if(o==true){
						slider2.setValue(y);}
                                                                                                // do all of the above for the next contour 
						//System.out.println(y);
						contours = contours.h_next();
			}
			
		     // show the thresholded image
		     canvasT.showImage(thresholdImage);  
						
		     // show the detected 'coloured' objects with rectangles drawn on on the initially captured image        
		     canvasW.showImage(orgImg);  			

	}
	      grabber.stop();
                              canvasW.dispose();
                              canvasT.dispose();
	
            }
       

/***CAM2***/
	// function for thresholding the original image
	static IplImage hsvThreshold(IplImage orgImg) {
		// 8-bit, 3- color =(RGB)
		IplImage imgHSV = cvCreateImage(cvGetSize(orgImg), 8, 3);

		cvCvtColor(orgImg, imgHSV, CV_BGR2HSV);
		// 8-bit 1- color = monochrome
		IplImage imgThreshold = cvCreateImage(cvGetSize(orgImg), 8, 1);
		// cvScalar : ( H , S , V, A)
		cvInRangeS(imgHSV, cvScalar(hueLowerR, 100, 100, 0),
				cvScalar(hueUpperR, 255, 255, 0), imgThreshold);
		cvReleaseImage(imgHSV);
		// filter the thresholded image to smooth things
		cvSmooth(imgThreshold, imgThreshold, CV_MEDIAN, 13);
		// return the processed image
		return imgThreshold;
	}
        
// --------------------------------------------------------------------------
// function for getting the dimensions
	static Dimension getCoordinates(IplImage thresholdImage) {
		int posX = 0;
		int posY = 0;
		CvMoments moments = new CvMoments();
		cvMoments(thresholdImage, moments, 1);
		// cv Spatial moment : Mji=sumx,y(I(x,y)â€¢xjâ€¢yi)
		// where I(x,y) is the intensity of the pixel (x, y).
		double momX10 = cvGetSpatialMoment(moments, 1, 0); // (x,y)
		double momY01 = cvGetSpatialMoment(moments, 0, 1);// (x,y)
		double area = cvGetCentralMoment(moments, 0, 0);
		posX = (int) (momX10 / area);
		posY = (int) (momY01 / area);
		return new Dimension(posX, posY);
	}	

/*** RESIZE ***/
public static BufferedImage resize(BufferedImage image, int width, int height) {
    BufferedImage bi = new BufferedImage(width, height, BufferedImage.TRANSLUCENT);
    Graphics2D g2d = (Graphics2D) bi.createGraphics();
    g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
	 g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
                  0.70f));
    g2d.drawImage(image, 0, 0, width, height, null);
    g2d.dispose();
    return bi;
}
}

/*
/*** Combo Box UI ***/
class MyComboBoxUI extends BasicComboBoxUI {
    public static ComponentUI createUI(JComponent c) {
      return new MyComboBoxUI();
    }

    protected JButton createArrowButton() {
      BufferedImage sizeImage = null;
try {
 sizeImage = ImageIO.read(new File("images/popup.png"));
 sizeImage = resize(sizeImage, 20, 20);
} catch (IOException e) {
            e.printStackTrace();
 }
      JButton button = new JButton(new ImageIcon(sizeImage));
      return button;
    }

    /*** RESIZE IN ANOTHER CLASS ***/
public static BufferedImage resize(BufferedImage image, int width, int height) {
    BufferedImage bi = new BufferedImage(width, height, BufferedImage.TRANSLUCENT);
    Graphics2D g2d = (Graphics2D) bi.createGraphics();
    g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
    g2d.drawImage(image, 0, 0, width, height, null);
    g2d.dispose();
    return bi;
}

/*** TRANSPARENCY ***/

}

